You have exported variables both on the player and the SpringArmPivot nodes
where you can control movement and FOV.

I'm willing to upload much more templates to kickstart projects on Godot.
This is my first asset, feel free to suggest assets to be made:

Discord : WaffleAWT
